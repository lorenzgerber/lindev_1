#ifndef FILE_D
#define FILE_D


#define D_MESSAGE "D\n"

#endif
