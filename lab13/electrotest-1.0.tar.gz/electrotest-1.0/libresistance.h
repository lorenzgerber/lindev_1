/**
 * This is the header file for resistance.so library
 *
 */

float calc_resistance(int count, char conn, float *array);
