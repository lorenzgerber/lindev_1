/**
 * This is the header file for component.so library
 *
 */

int e_resistance (float orig_resistance, float *res_array);
