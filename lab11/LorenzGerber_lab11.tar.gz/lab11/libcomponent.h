/*
 * @file lincomponent.h
 *
 * @author Lorenz Gerber
 * @date 06.08.2017
 * @brief lincomponent library header.
 *
 */
int findresistors (float orig_resistance, float *res_array);
