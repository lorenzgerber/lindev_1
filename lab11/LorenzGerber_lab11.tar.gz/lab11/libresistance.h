/*
 * @file linresistance.h
 *
 * @author Lorenz Gerber
 * @date 06.08.2017
 * @brief linresistance library header.
 *
 */
float calc_resistance(int count, char conn, float *array);

