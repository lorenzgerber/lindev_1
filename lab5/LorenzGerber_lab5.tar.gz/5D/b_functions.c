/* b_functions.c  */


#include <stdio.h>

#include "b.h"

void print_B()
{
	printf(B_MESSAGE);
}
