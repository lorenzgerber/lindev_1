#include <stdio.h>
#include <stdlib.h>

int add();

int main(void){
  int result = 0;
  result = add();

  printf("%d\n", result);

  return 0;
}
